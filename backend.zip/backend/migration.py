# migration.py - Run this to migrate your database

import os
import sys
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import OperationalError

# Import your models
import models  # Your new enhanced models

def run_migration():
    """
    Database Migration Script
    
    This script will:
    1. Create new tables for personalization features
    2. Add new columns to existing tables
    3. Preserve existing data
    4. Set up indexes for performance
    """
    
    # Database configuration
    SQLALCHEMY_DATABASE_URL = "sqlite:///./brainwave.db"
    
    print("Starting database migration...")
    
    # Create engine
    engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
    
    try:
        # Test connection
        with engine.connect() as connection:
            print("✓ Database connection successful")
        
        # Create all new tables and columns
        print("Creating new tables and adding columns...")
        
        # This will create all tables defined in models.py
        # Existing tables will not be affected, only new ones will be created
        models.Base.metadata.create_all(bind=engine)
        
        print("✓ New tables created successfully")
        
        # Add new columns to existing tables
        add_new_columns(engine)
        
        # Set up indexes for better performance
        create_indexes(engine)
        
        # Initialize default data
        initialize_default_data(engine)
        
        print("✓ Database migration completed successfully!")
        print("\nNew tables created:")
        print("- user_personality_profiles")
        print("- learning_patterns") 
        print("- conversation_memories")
        print("- user_preferences")
        print("- topic_mastery")
        print("- global_knowledge_base")
        print("- ai_response_improvements")
        print("- common_misconceptions")
        print("- user_feedback")
        print("- ai_learning_metrics")
        print("- flashcard_sets")
        print("- flashcards")
        print("- flashcard_study_sessions")
        
        print("\nEnhanced existing tables:")
        print("- chat_messages (added: user_sentiment, ai_confidence, response_time)")
        print("- chat_sessions (added: session_summary, emotional_tone, difficulty_level)")
        print("- activities (added: question_type, difficulty_level, user_satisfaction, time_to_understand, follow_up_questions)")
        print("- notes (added: ai_generated, source_chat_sessions, difficulty_level, estimated_study_time)")
        print("- user_stats (added: total_concepts_learned, favorite_learning_time, average_session_rating, total_questions_asked)")
        
    except Exception as e:
        print(f"✗ Migration failed: {str(e)}")
        return False
    
    return True

def add_new_columns(engine):
    """Add new columns to existing tables"""
    
    new_columns = {
        'chat_messages': [
            'ALTER TABLE chat_messages ADD COLUMN user_sentiment REAL',
            'ALTER TABLE chat_messages ADD COLUMN ai_confidence REAL', 
            'ALTER TABLE chat_messages ADD COLUMN response_time REAL'
        ],
        'chat_sessions': [
            'ALTER TABLE chat_sessions ADD COLUMN session_summary TEXT',
            'ALTER TABLE chat_sessions ADD COLUMN emotional_tone TEXT',
            'ALTER TABLE chat_sessions ADD COLUMN difficulty_level TEXT'
        ],
        'activities': [
            'ALTER TABLE activities ADD COLUMN question_type TEXT',
            'ALTER TABLE activities ADD COLUMN difficulty_level TEXT',
            'ALTER TABLE activities ADD COLUMN user_satisfaction INTEGER',
            'ALTER TABLE activities ADD COLUMN time_to_understand REAL',
            'ALTER TABLE activities ADD COLUMN follow_up_questions INTEGER DEFAULT 0'
        ],
        'notes': [
            'ALTER TABLE notes ADD COLUMN ai_generated BOOLEAN DEFAULT 0',
            'ALTER TABLE notes ADD COLUMN source_chat_sessions TEXT',
            'ALTER TABLE notes ADD COLUMN difficulty_level TEXT',
            'ALTER TABLE notes ADD COLUMN estimated_study_time INTEGER'
        ],
        'user_stats': [
            'ALTER TABLE user_stats ADD COLUMN total_concepts_learned INTEGER DEFAULT 0',
            'ALTER TABLE user_stats ADD COLUMN favorite_learning_time TEXT',
            'ALTER TABLE user_stats ADD COLUMN average_session_rating REAL DEFAULT 0.0',
            'ALTER TABLE user_stats ADD COLUMN total_questions_asked INTEGER DEFAULT 0'
        ]
    }
    
    with engine.connect() as connection:
        for table, columns in new_columns.items():
            for column_sql in columns:
                try:
                    connection.execute(text(column_sql))
                    column_name = column_sql.split('ADD COLUMN')[1].split()[0] if 'ADD COLUMN' in column_sql else 'unknown'
                    print(f"✓ Added column: {column_name} to {table}")
                except OperationalError as e:
                    if "duplicate column name" in str(e).lower():
                        column_name = column_sql.split('ADD COLUMN')[1].split()[0] if 'ADD COLUMN' in column_sql else 'unknown'
                        print(f"- Column already exists: {column_name} in {table}")
                    else:
                        print(f"✗ Error adding column: {e}")
        
        connection.commit()

def create_indexes(engine):
    """Create indexes for better performance"""
    
    indexes = [
        'CREATE INDEX IF NOT EXISTS idx_chat_messages_timestamp ON chat_messages(timestamp)',
        'CREATE INDEX IF NOT EXISTS idx_chat_messages_sentiment ON chat_messages(user_sentiment)',
        'CREATE INDEX IF NOT EXISTS idx_conversation_memories_importance ON conversation_memories(importance_score)',
        'CREATE INDEX IF NOT EXISTS idx_conversation_memories_type ON conversation_memories(memory_type)',
        'CREATE INDEX IF NOT EXISTS idx_topic_mastery_level ON topic_mastery(mastery_level)',
        'CREATE INDEX IF NOT EXISTS idx_topic_mastery_topic ON topic_mastery(topic_name)',
        'CREATE INDEX IF NOT EXISTS idx_global_kb_topic ON global_knowledge_base(topic_category)',
        'CREATE INDEX IF NOT EXISTS idx_global_kb_success ON global_knowledge_base(success_rate)',
        'CREATE INDEX IF NOT EXISTS idx_user_feedback_rating ON user_feedback(rating)',
        'CREATE INDEX IF NOT EXISTS idx_user_feedback_type ON user_feedback(feedback_type)',
        'CREATE INDEX IF NOT EXISTS idx_misconceptions_topic ON common_misconceptions(topic)',
        'CREATE INDEX IF NOT EXISTS idx_flashcard_sets_user ON flashcard_sets(user_id)',
        'CREATE INDEX IF NOT EXISTS idx_flashcards_set ON flashcards(set_id)',
        'CREATE INDEX IF NOT EXISTS idx_flashcard_sessions_user ON flashcard_study_sessions(user_id)',
        'CREATE INDEX IF NOT EXISTS idx_flashcard_sessions_set ON flashcard_study_sessions(set_id)'
    ]
    
    with engine.connect() as connection:
        for index_sql in indexes:
            try:
                connection.execute(text(index_sql))
                index_name = index_sql.split()[5]  # Extract index name
                print(f"✓ Created index: {index_name}")
            except Exception as e:
                print(f"- Index might already exist: {e}")
        
        connection.commit()

def initialize_default_data(engine):
    """Initialize some default data for the AI learning system"""
    
    # Create session
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    
    try:
        # Check if we already have global knowledge base entries
        existing_kb = db.execute(text("SELECT COUNT(*) FROM global_knowledge_base")).scalar()
        
        if existing_kb == 0:
            # Add some initial knowledge base entries
            initial_knowledge = [
                {
                    'question_pattern': 'What is {concept} in {subject}?',
                    'response_template': 'Let me explain {concept} in {subject}. {concept} is defined as...',
                    'topic_category': 'definition',
                    'difficulty_level': 'beginner',
                    'success_rate': 0.8
                },
                {
                    'question_pattern': 'How do you solve {problem_type}?',
                    'response_template': 'To solve {problem_type}, follow these steps: 1) First... 2) Then... 3) Finally...',
                    'topic_category': 'problem_solving',
                    'difficulty_level': 'intermediate',
                    'success_rate': 0.75
                },
                {
                    'question_pattern': 'Can you give me an example of {concept}?',
                    'response_template': 'Here\'s a practical example of {concept}: [specific example]. This shows how...',
                    'topic_category': 'examples',
                    'difficulty_level': 'beginner',
                    'success_rate': 0.85
                }
            ]
            
            for kb_entry in initial_knowledge:
                insert_sql = text("""
                    INSERT INTO global_knowledge_base 
                    (question_pattern, response_template, topic_category, difficulty_level, success_rate, usage_count, is_active)
                    VALUES (:question_pattern, :response_template, :topic_category, :difficulty_level, :success_rate, 0, 1)
                """)
                db.execute(insert_sql, kb_entry)
            
            print("✓ Initialized global knowledge base with default entries")
        
        # Add some common misconceptions
        existing_misconceptions = db.execute(text("SELECT COUNT(*) FROM common_misconceptions")).scalar()
        
        if existing_misconceptions == 0:
            misconceptions = [
                {
                    'topic': 'mathematics',
                    'misconception_text': 'Division always makes numbers smaller',
                    'correct_explanation': 'Division by numbers less than 1 actually makes the result larger. For example, 8 ÷ 0.5 = 16.',
                    'trigger_phrases': '["division makes smaller", "dividing reduces"]',
                    'confusion_indicators': '["why is result bigger", "division should decrease"]'
                },
                {
                    'topic': 'physics',
                    'misconception_text': 'Heavier objects fall faster',
                    'correct_explanation': 'In the absence of air resistance, all objects fall at the same rate regardless of their mass.',
                    'trigger_phrases': '["heavy falls faster", "weight affects falling"]',
                    'confusion_indicators': '["why same speed", "mass and gravity"]'
                },
                {
                    'topic': 'biology',
                    'misconception_text': 'Humans only use 10% of their brain',
                    'correct_explanation': 'Humans use virtually all of their brain. Brain imaging shows activity throughout the brain even during simple tasks.',
                    'trigger_phrases': '["10% of brain", "unused brain capacity"]',
                    'confusion_indicators': '["brain potential", "unlock brain power"]'
                }
            ]
            
            for misconception in misconceptions:
                insert_sql = text("""
                    INSERT INTO common_misconceptions 
                    (topic, misconception_text, correct_explanation, trigger_phrases, confusion_indicators, times_encountered)
                    VALUES (:topic, :misconception_text, :correct_explanation, :trigger_phrases, :confusion_indicators, 0)
                """)
                db.execute(insert_sql, misconception)
            
            print("✓ Initialized common misconceptions database")
        
        db.commit()
        
    except Exception as e:
        print(f"Warning: Could not initialize default data: {e}")
        db.rollback()
    finally:
        db.close()

def backup_database():
    """Create a backup of the current database before migration"""
    import shutil
    from datetime import datetime
    
    db_file = "brainwave.db"
    
    if os.path.exists(db_file):
        backup_name = f"brainwave_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        shutil.copy2(db_file, backup_name)
        print(f"✓ Database backed up as: {backup_name}")
        return backup_name
    else:
        print("- No existing database found, creating new one")
        return None

def verify_migration():
    """Verify that the migration was successful"""
    
    SQLALCHEMY_DATABASE_URL = "sqlite:///./brainwave.db"
    engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
    
    required_tables = [
        'users', 'chat_sessions', 'chat_messages', 'user_stats', 'notes', 'activities',
        'user_personality_profiles', 'learning_patterns', 'conversation_memories',
        'user_preferences', 'topic_mastery', 'global_knowledge_base',
        'ai_response_improvements', 'common_misconceptions', 'user_feedback',
        'ai_learning_metrics', 'flashcard_sets', 'flashcards', 'flashcard_study_sessions'
    ]
    
    with engine.connect() as connection:
        # Check if all tables exist
        for table in required_tables:
            try:
                result = connection.execute(text(f"SELECT 1 FROM {table} LIMIT 1"))
                print(f"✓ Table '{table}' exists and accessible")
            except Exception as e:
                print(f"✗ Issue with table '{table}': {e}")
                return False
    
    print("✓ Migration verification completed successfully!")
    return True

def check_required_columns():
    """Check if all required columns exist in existing tables"""
    
    SQLALCHEMY_DATABASE_URL = "sqlite:///./brainwave.db"
    engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
    
    required_columns = {
        'activities': ['question_type', 'difficulty_level', 'user_satisfaction', 'time_to_understand', 'follow_up_questions'],
        'chat_messages': ['user_sentiment', 'ai_confidence', 'response_time'],
        'chat_sessions': ['session_summary', 'emotional_tone', 'difficulty_level'],
        'notes': ['ai_generated', 'source_chat_sessions', 'difficulty_level', 'estimated_study_time'],
        'user_stats': ['total_concepts_learned', 'favorite_learning_time', 'average_session_rating', 'total_questions_asked']
    }
    
    with engine.connect() as connection:
        for table, columns in required_columns.items():
            try:
                # Get table info
                result = connection.execute(text(f"PRAGMA table_info({table})"))
                existing_columns = [row[1] for row in result.fetchall()]
                
                missing_columns = [col for col in columns if col not in existing_columns]
                if missing_columns:
                    print(f"✗ Table '{table}' missing columns: {missing_columns}")
                else:
                    print(f"✓ Table '{table}' has all required columns")
                    
            except Exception as e:
                print(f"✗ Error checking table '{table}': {e}")

if __name__ == "__main__":
    print("Brainwave Database Migration Tool")
    print("=================================")
    
    # Check current state
    print("\nChecking current database state...")
    check_required_columns()
    
    # Create backup
    backup_file = backup_database()
    
    # Ask for confirmation
    print("\nThis will modify your database structure.")
    if backup_file:
        print(f"A backup has been created: {backup_file}")
    
    confirm = input("Do you want to proceed with the migration? (yes/no): ").lower()
    
    if confirm in ['yes', 'y']:
        success = run_migration()
        
        if success:
            print("\nVerifying migration...")
            verify_migration()
            print("\n" + "="*50)
            print("MIGRATION COMPLETED SUCCESSFULLY!")
            print("="*50)
            print("You can now restart your application to use the new features.")
            print("\nNew features enabled:")
            print("- Enhanced user personalization")
            print("- AI learning and improvement")
            print("- Comprehensive flashcard system")
            print("- Advanced analytics and insights")
            print("- Global knowledge base")
            print("- Misconception detection and correction")
        else:
            print("\nMigration failed. Please check the error messages above.")
            if backup_file:
                print(f"Your original database backup is available at: {backup_file}")
    else:
        print("Migration cancelled.")
        if backup_file and os.path.exists(backup_file):
            os.remove(backup_file)
            print("Backup file removed.")